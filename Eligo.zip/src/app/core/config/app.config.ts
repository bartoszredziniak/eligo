export const APP_CONFIG = {
  shopLink: 'https://allegro.pl',
};
