import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

export class ThreeSceneFacade {
  private scene!: THREE.Scene;
  private camera!: THREE.OrthographicCamera;
  private renderer!: THREE.WebGLRenderer;
  private controls!: OrbitControls;
  private animationId: number | null = null;
  
  // Orthographic camera settings
  private readonly frustumSize = 1000; // Visible area size in mm roughly

  constructor(private readonly container: HTMLElement) {}

  init(): void {
    this.initScene();
    this.initCamera();
    this.initRenderer();
    this.initControls();
    this.initLights();
    this.startAnimationLoop();
  }

  private initScene(): void {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xfafaf9); // warm grey - stone-50
  }

  setBackground(color: THREE.Color | null): void {
    if (this.scene) {
      this.scene.background = color;
    }
  }

  private initCamera(): void {
    const { clientWidth, clientHeight } = this.container;
    const aspect = clientWidth / clientHeight;
    
    // Setup Orthographic Camera
    // Left, Right, Top, Bottom, Near, Far
    this.camera = new THREE.OrthographicCamera(
      this.frustumSize * aspect / -2,
      this.frustumSize * aspect / 2,
      this.frustumSize / 2,
      this.frustumSize / -2,
      -2000, // Near plane (allows things to be behind camera target slightly)
      5000   // Far plane
    );

    // Isometric position (Key is all axis have same magnitude roughly)
    // We adjust distances to ensure good initial zoom
    this.camera.position.set(500, 500, 500); 
    this.camera.zoom = 1;
    this.camera.lookAt(0, 0, 0);
  }

  private initRenderer(): void {
    this.renderer = new THREE.WebGLRenderer({ 
      antialias: true, 
      alpha: true,
      logarithmicDepthBuffer: true // Helps with z-fighting in ortho
    });
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Cap pixel ratio for performance
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap; // Softer shadows
    
    this.container.appendChild(this.renderer.domElement);
  }

  private initControls(): void {
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.05;
    
    // Zoom limits for Orthographic (Zoom is actually a scale factor)
    this.controls.minZoom = 0.5;
    this.controls.maxZoom = 4;
    
    // Restrict Rotation for better Mobile experience (Optional, but often requested)
    // For now, we leave it free but maybe we could restrict polar angles
    // this.controls.maxPolarAngle = Math.PI / 2; // Prevent going below ground
  }

  setControlsTarget(x: number, y: number, z: number): void {
    if (this.controls) {
      this.controls.target.set(x, y, z);
      this.controls.update();
    }
  }

  resetCamera(): void {
    if (this.controls && this.camera) {
      const target = this.controls.target;
      
      // Reset to isometric angle
      this.camera.position.set(target.x + 500, 500, target.z + 500);
      this.camera.lookAt(target.x, 0, target.z);
      this.camera.zoom = 1;
      this.camera.updateProjectionMatrix(); // Important for ortho zoom handling
      
      this.controls.update();
    }
  }

  enableControls(enabled: boolean): void {
    if (this.controls) {
      this.controls.enabled = enabled;
    }
  }

  private initLights(): void {
    // 1. Ambient Light - Soft global illumination
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    this.scene.add(ambientLight);

    // 2. Main Directional Light (Sun) - Creates defined shadows
    const mainLight = new THREE.DirectionalLight(0xffffff, 0.6);
    mainLight.position.set(500, 1000, 500);
    mainLight.castShadow = true;
    
    // Improve shadow quality for Ortho
    const shadowSize = 2000;
    mainLight.shadow.camera.left = -shadowSize;
    mainLight.shadow.camera.right = shadowSize;
    mainLight.shadow.camera.top = shadowSize;
    mainLight.shadow.camera.bottom = -shadowSize;
    mainLight.shadow.mapSize.width = 2048;
    mainLight.shadow.mapSize.height = 2048;
    mainLight.shadow.bias = -0.0005; // Remove artifacts
    
    this.scene.add(mainLight);

    // 3. Fill Light - Softens harsh shadows
    const fillLight = new THREE.DirectionalLight(0xeef2ff, 0.4); // Cool bi-color fill
    fillLight.position.set(-500, 300, -500);
    this.scene.add(fillLight);
  }

  private startAnimationLoop(): void {
    const animate = () => {
      this.animationId = requestAnimationFrame(animate);
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
    };
    animate();
  }

  resize(width: number, height: number): void {
    const aspect = width / height;
    
    // Update Orthographic Frustum
    this.camera.left = -this.frustumSize * aspect / 2;
    this.camera.right = this.frustumSize * aspect / 2;
    this.camera.top = this.frustumSize / 2;
    this.camera.bottom = -this.frustumSize / 2;
    
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  dispose(): void {
    if (this.animationId !== null) {
      cancelAnimationFrame(this.animationId);
    }
    
    if (this.renderer && this.renderer.domElement) {
      this.renderer.domElement.remove();
    }

    this.renderer.dispose();
    this.controls.dispose();
    
    this.scene.traverse((object) => {
      if (object instanceof THREE.Mesh) {
         if (object.geometry) {
           object.geometry.dispose();
         }
      }
    });
    
    this.scene.clear();
  }

  getScene(): THREE.Scene {
    return this.scene;
  }

  getCamera(): THREE.OrthographicCamera {
    return this.camera;
  }

  getRenderer(): THREE.WebGLRenderer {
    return this.renderer;
  }

  getControls(): OrbitControls {
    return this.controls;
  }

  render(): void {
    this.renderer.render(this.scene, this.camera);
  }
}
